# Telegram AI Bot (Text + Images) — бесплатные нейросети Pollinations.AI

Этот бот умеет:
- отвечать текстом (генерация текста)
- генерировать картинки по запросу
- работать без платных ключей нейросети (используется публичный API Pollinations.AI)

## 1) Создай бота в Telegram
1. Открой **@BotFather**
2. Выполни `/newbot`
3. Скопируй токен вида `123456:ABC-DEF...`

## 2) Установка (Python 3.10+)
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
```

## 3) Настройка переменных окружения
Создай файл **.env** рядом с `bot.py`:

```env
TELEGRAM_BOT_TOKEN=PASTE_YOUR_TOKEN_HERE
TEXT_MODEL=openai
IMAGE_MODEL=flux
```

> Важно: `.env` не надо выкладывать в GitHub.

## 4) Запуск
```bash
python bot.py
```

## Команды в Telegram
- `/start` — приветствие
- `/help` — подсказка
- `/text <запрос>` — получить текст
- `/img <запрос>` — получить картинку
- `/models_text` — доступные текстовые модели
- `/models_img` — доступные модели картинок

### Быстрые сообщения
- Просто напиши текст — бот ответит текстом
- Напиши `img: кот в очках` — бот сгенерирует картинку

## Примечание про бесплатность / лимиты
Pollinations.AI заявляет быстрый старт без регистрации/ключей, но у публичных эндпоинтов могут быть ограничения и временные сбои.
Документация: https://github.com/pollinations/pollinations/blob/master/APIDOCS.md
