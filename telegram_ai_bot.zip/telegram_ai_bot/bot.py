from __future__ import annotations

import io
import logging
import os

from dotenv import load_dotenv
from telegram import Update
from telegram.constants import ChatAction
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

from config import load_settings
from ai.pollinations import generate_text, generate_image_bytes, list_text_models, list_image_models

load_dotenv()

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("tg-ai-bot")

HELP_TEXT = (
    "🤖 *AI бот (текст + картинки)*\n\n"
    "Команды:\n"
    "• `/text <запрос>` — ответ текстом\n"
    "• `/img <запрос>` — сгенерировать картинку\n"
    "• `/models_text` — список текстовых моделей\n"
    "• `/models_img` — список моделей картинок\n\n"
    "Быстро:\n"
    "• Просто напиши сообщение — отвечу текстом\n"
    "• Напиши `img: кот в очках` — пришлю картинку\n"
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_markdown(
        "Привет! Я могу генерировать *текст* и *картинки*.\n\n" + HELP_TEXT
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_markdown(HELP_TEXT)

def _extract_after_command(text: str) -> str:
    parts = (text or "").split(maxsplit=1)
    if len(parts) == 2:
        return parts[1].strip()
    return ""

async def text_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = context.application.bot_data["settings"]
    prompt = _extract_after_command(update.message.text)
    await update.message.chat.send_action(ChatAction.TYPING)
    try:
        answer = generate_text(
            prompt,
            model=settings.text_model,
            timeout=settings.request_timeout_sec,
            max_len=settings.max_prompt_len,
        )
    except Exception as e:
        logger.exception("Text generation failed")
        answer = f"⚠️ Ошибка генерации текста: {e}"
    await update.message.reply_text(answer)

async def img_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = context.application.bot_data["settings"]
    prompt = _extract_after_command(update.message.text)
    await update.message.chat.send_action(ChatAction.UPLOAD_PHOTO)
    try:
        img = generate_image_bytes(
            prompt,
            model=settings.image_model,
            width=1024,
            height=1024,
            timeout=settings.request_timeout_sec,
            max_len=settings.max_prompt_len,
        )
        bio = io.BytesIO(img)
        bio.name = "image.png"
        await update.message.reply_photo(photo=bio, caption=f"🖼️ {prompt[:900]}")
    except Exception as e:
        logger.exception("Image generation failed")
        await update.message.reply_text(f"⚠️ Ошибка генерации картинки: {e}")

async def models_text_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.chat.send_action(ChatAction.TYPING)
    try:
        models = list_text_models()
        txt = "Доступные *текстовые* модели:\n" + "\n".join(f"• `{m}`" for m in models[:80])
        if len(models) > 80:
            txt += f"\n…и ещё {len(models)-80}"
        await update.message.reply_markdown(txt)
    except Exception as e:
        await update.message.reply_text(f"⚠️ Не получилось получить список моделей: {e}")

async def models_img_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.chat.send_action(ChatAction.TYPING)
    try:
        models = list_image_models()
        txt = "Доступные *модели картинок*:\n" + "\n".join(f"• `{m}`" for m in models[:80])
        if len(models) > 80:
            txt += f"\n…и ещё {len(models)-80}"
        await update.message.reply_markdown(txt)
    except Exception as e:
        await update.message.reply_text(f"⚠️ Не получилось получить список моделей: {e}")

def _looks_like_image_request(text: str) -> bool:
    t = (text or "").strip().lower()
    return t.startswith("img:") or t.startswith("image:") or t.startswith("картинка:") or t.startswith("фото:")

def _strip_image_prefix(text: str) -> str:
    t = (text or "").strip()
    for pref in ("img:", "image:", "картинка:", "фото:"):
        if t.lower().startswith(pref):
            return t[len(pref):].strip()
    return t

async def on_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not update.message or not update.message.text:
        return
    text = update.message.text.strip()

    # Игнорируем сообщения-команды (их обработают CommandHandler)
    if text.startswith("/"):
        return

    settings = context.application.bot_data["settings"]

    if _looks_like_image_request(text):
        prompt = _strip_image_prefix(text)
        await update.message.chat.send_action(ChatAction.UPLOAD_PHOTO)
        try:
            img = generate_image_bytes(
                prompt,
                model=settings.image_model,
                width=1024,
                height=1024,
                timeout=settings.request_timeout_sec,
                max_len=settings.max_prompt_len,
            )
            bio = io.BytesIO(img)
            bio.name = "image.png"
            await update.message.reply_photo(photo=bio, caption=f"🖼️ {prompt[:900]}")
        except Exception as e:
            logger.exception("Image generation failed")
            await update.message.reply_text(f"⚠️ Ошибка генерации картинки: {e}")
        return

    await update.message.chat.send_action(ChatAction.TYPING)
    try:
        answer = generate_text(
            text,
            model=settings.text_model,
            timeout=settings.request_timeout_sec,
            max_len=settings.max_prompt_len,
        )
    except Exception as e:
        logger.exception("Text generation failed")
        answer = f"⚠️ Ошибка генерации текста: {e}"
    await update.message.reply_text(answer)

def main() -> None:
    settings = load_settings()

    app = Application.builder().token(settings.telegram_bot_token).build()
    app.bot_data["settings"] = settings

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("text", text_cmd))
    app.add_handler(CommandHandler("img", img_cmd))
    app.add_handler(CommandHandler("models_text", models_text_cmd))
    app.add_handler(CommandHandler("models_img", models_img_cmd))

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_message))

    logger.info("Bot started.")
    app.run_polling(close_loop=False)

if __name__ == "__main__":
    main()
