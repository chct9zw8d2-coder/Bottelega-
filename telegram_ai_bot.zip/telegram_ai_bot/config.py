import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    telegram_bot_token: str
    text_model: str = "openai"
    image_model: str = "flux"
    request_timeout_sec: int = 90
    max_prompt_len: int = 2000

def load_settings() -> Settings:
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        raise RuntimeError(
            "Не найден TELEGRAM_BOT_TOKEN. Создай .env и добавь TELEGRAM_BOT_TOKEN=... (см. README)."
        )
    return Settings(
        telegram_bot_token=token,
        text_model=os.getenv("TEXT_MODEL", "openai").strip() or "openai",
        image_model=os.getenv("IMAGE_MODEL", "flux").strip() or "flux",
        request_timeout_sec=int(os.getenv("REQUEST_TIMEOUT_SEC", "90")),
        max_prompt_len=int(os.getenv("MAX_PROMPT_LEN", "2000")),
    )
